export class CreateAppointmentDto {
    name: string;
    phoneNumber: string;
    service: string;
    date: Date;
}
