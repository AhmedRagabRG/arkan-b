export class CreateServiceDto {
    title: string
    img: string
    content?: string
}
