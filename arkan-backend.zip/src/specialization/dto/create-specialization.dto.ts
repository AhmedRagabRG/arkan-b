export class CreateSpecializationDto {
    name: string;
    img?: string;
    content?: string;
}
