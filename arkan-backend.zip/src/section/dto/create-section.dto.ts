export class CreateSectionDto {}
