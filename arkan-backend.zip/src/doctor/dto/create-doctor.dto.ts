export class CreateDoctorDto {
    name: string;
    img: string;
    specializationId: number;
    days: string;
}
